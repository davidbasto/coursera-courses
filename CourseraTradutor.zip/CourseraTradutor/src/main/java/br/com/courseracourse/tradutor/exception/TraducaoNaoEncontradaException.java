package br.com.courseracourse.tradutor.exception;

public class TraducaoNaoEncontradaException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
